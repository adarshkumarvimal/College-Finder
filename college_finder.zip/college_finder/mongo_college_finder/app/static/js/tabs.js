document.addEventListener("DOMContentLoaded", () => {
  const buttons = document.querySelectorAll(".tab-btn");
  const panels = document.querySelectorAll(".tab-panel");

  function activate(tab) {
    buttons.forEach((b) => {
      const isActive = b.dataset.tab === tab;
      b.setAttribute("aria-selected", String(isActive));
      b.classList.toggle("bg-black", isActive);
      b.classList.toggle("text-white", isActive);
    });
    panels.forEach((p) => {
      p.classList.toggle("hidden", p.id !== `tab-${tab}`);
    });
  }

  buttons.forEach((b) => b.addEventListener("click", () => activate(b.dataset.tab)));
  activate("overview");
});
