"""scheduler.py"""
import asyncio
from datetime import datetime, timedelta
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger
from dateutil import tz
from config import SCHEDULE_REFRESH_CRON
from .db.mongo import colleges_col
from .services.refresher import refresh_college

scheduler = AsyncIOScheduler()

async def _refresh_due_colleges():
    col = await colleges_col()
    # Find stale colleges (older than 7 days)
    cutoff = (datetime.now(tz.UTC) - timedelta(days=7)).isoformat()
    cursor = col.find({"$or": [{"next_due_refresh": {"$lte": cutoff}}, {"next_due_refresh": {"$exists": False}}]}, {"_id": 1})
    slugs = [doc["_id"] async for doc in cursor]
    # Cap per run to avoid stampede
    for slug in slugs[:200]:
        asyncio.create_task(refresh_college(slug))

def init_scheduler():
    """scheduler"""
    cron = CronTrigger.from_crontab(SCHEDULE_REFRESH_CRON)
    scheduler.add_job(_refresh_due_colleges, cron, id="refresh_due_colleges", replace_existing=True)
    scheduler.start()
