"""mongo.py"""
from typing import Optional, Any, Dict
from motor.motor_asyncio import AsyncIOMotorClient
from app.config import MONGO_URL, MONGO_DB

_client: Optional[AsyncIOMotorClient] = None

async def get_client() -> AsyncIOMotorClient:
    """get_client"""
    global _client
    if _client is None:
        _client = AsyncIOMotorClient(MONGO_URL, uuidRepresentation="standard")
    return _client

async def get_db():
    """get_db"""
    client = await get_client()
    return client[MONGO_DB]

# ---------- DAO helpers ----------
async def colleges_col():
    """colleges_col"""
    db = await get_db()
    return db["colleges"]

async def upsert_college(slug: str, patch: Dict[str, Any]) -> None:
    """upsert_college"""
    col = await colleges_col()
    await col.update_one({"_id": slug}, {"$set": patch, "$setOnInsert": {"_id": slug}}, upsert=True)

async def find_college(slug: str) -> Optional[Dict[str, Any]]:
    """find_college"""
    col = await colleges_col()
    return await col.find_one({"_id": slug}, {"_id": 0})

async def search_colleges_by_name(q: str, limit: int = 10):
    """search_college_by_name"""
    col = await colleges_col()
    # requires text index on names.official + names.aliases
    cursor = col.find({"$text": {"$search": q}}, {"_id": 0}).limit(limit)
    return [doc async for doc in cursor]
