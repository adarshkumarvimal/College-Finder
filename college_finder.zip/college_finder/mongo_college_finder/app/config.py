"""config.py"""
import os
from dotenv import load_dotenv

load_dotenv()

# Required
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")

# Model + timeout (safe defaults)
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini")  # e.g. "gpt-4o", "gpt-4o-mini"
OPENAI_TIMEOUT = float(os.getenv("OPENAI_TIMEOUT", "20"))  # seconds

# Redis cache (optional but recommended)
REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379/0")
USE_REDIS = os.getenv("USE_REDIS", "1") == "1"

# Cache policy
CACHE_TTL = int(os.getenv("CACHE_TTL", "86400"))      # 24h fresh
STALE_TTL = int(os.getenv("STALE_TTL", "604800"))     # 7 days allowed stale

# Mongo
MONGO_URL = os.getenv("MONGO_URL", "mongodb://localhost:27017")
MONGO_DB = os.getenv("MONGO_DB", "college_finder")

# Scheduler
SCHEDULE_REFRESH_CRON = os.getenv("SCHEDULE_REFRESH_CRON", "0 3 * * *")  # 03:00 daily

# Env flag (optional)
ENV = os.getenv("ENV", "development")
