"""nirf.py"""
from datetime import datetime
import re
from typing import Dict, Any, List, Optional
import httpx
from dateutil import tz

# Configure year/endpoints here; NIRF tends to publish CSV/Excel/HTML tables each cycle.
NIRF_YEAR = 2025
# example landing page
NIRF_ENGINEERING_URL = "https://www.nirfindia.org/2025/EngineeringRanking.html"

async def fetch_nirf_engineering_table() -> Optional[str]:
    """fetch_nirf_engineering_table"""
    async with httpx.AsyncClient(timeout=20) as client:
        r = await client.get(NIRF_ENGINEERING_URL, headers={"User-Agent": "CollegeFinderBot/1.0"})
        r.raise_for_status()
        return r.text

def _parse_engineering_table(html: str) -> List[Dict[str, Any]]:
    """
    Parse NIRF HTML for engineering ranks.
    Return: list of { rank:int, name:str, city:str|None, state:str|None }
    NOTE: This is a simplistic example; you should tailor selectors to the current year's HTML.
    """
    # Very light parsing to stay dependency-light. For production use lxml/BeautifulSoup.
    rows: List[Dict[str, Any]] = []
    # naive parse: look for lines with pattern "> 1 < ... IIT ...", etc.
    pattern = re.compile(r"<tr[^>]*>\s*<td[^>]*>\s*(\d+)\s*</td>.*?<td[^>]*>\s*([^<]+)\s*</td>",
                         re.I | re.S)
    for m in pattern.finditer(html):
        rank = int(m.group(1))
        name = m.group(2).strip()
        rows.append({"rank": rank, "name": name})
    return rows

async def get_nirf_engineering_ranks() -> Dict[str, Any]:
    """get_nirf_engineering_ranks"""
    html = await fetch_nirf_engineering_table()
    if not html:
        return {"year": NIRF_YEAR, "ranks": [], "fetched_at": datetime.now(tz.UTC).isoformat()}

    rows = _parse_engineering_table(html)
    return {
        "year": NIRF_YEAR,
        "category": "Engineering",
        "ranks": rows,
        "source_url": NIRF_ENGINEERING_URL,
        "fetched_at": datetime.now(tz.UTC).isoformat(),
    }
