"""refresher.py"""
from typing import Dict, Any
from datetime import datetime, timedelta
from dateutil import tz
from app.db.mongo import upsert_college, find_college
from app.services.summarizer import summarize_sections
from .fetchers.nirf import get_nirf_engineering_ranks


# --- Utility merge helpers ---

def now_iso():
    """now_iso"""
    return datetime.now(tz.UTC).isoformat()

def merge_rankings(existing: Dict[str, Any], nirf: Dict[str, Any]) -> Dict[str, Any]:
    """merge_rankings"""
    rankings = existing.get("rankings", {}) or {}
    rankings["nirf"] = {
        "year": nirf.get("year"),
        "category": nirf.get("category", "Engineering"),
        "table": nirf.get("ranks", []),
        "source_url": nirf.get("source_url"),
        "last_seen": nirf.get("fetched_at"),
    }
    return rankings

async def refresh_college(slug: str, seed_names: Dict[str, Any] | None = None) -> None:
    """
    Refresh pipeline for a single college:
    1) Load existing record (if any)
    2) Fetch authoritative sources (example: NIRF)
    3) Merge into record with per-field timestamps
    4) Summarize human-readable sections from facts (RAG)
    5) Save
    """
    existing = await find_college(slug) or {}
    record = dict(existing) if existing else {
        "slug": slug,
        "names": seed_names or {},
        "location": {},
        "regulatory": {},
        "rankings": {},
        "admissions": {},
        "fees": {},
        "placements": {},
        "courses": [],
        "audit": {"created_at": now_iso(), "sources": []},
    }

    # 2) Fetch sources (add more fetchers here)
    try:
        nirf = await get_nirf_engineering_ranks()
        record["rankings"] = merge_rankings(record, nirf)
        record["audit"]["sources"].append({"field": "rankings.nirf", "url": nirf.get("source_url"),
                                           "fetched_at": nirf.get("fetched_at")})
    except Exception:
        # ignore NIRF fetch failure, keep other fields
        pass

    # 3) Update timestamps
    record["audit"]["updated_at"] = now_iso()
    record["last_full_refresh"] = datetime.now(tz.UTC).isoformat()
    record["next_due_refresh"] = (datetime.now(tz.UTC) + timedelta(days=7)).isoformat()

    # 4) Summaries (RAG) from current facts
    facts = {
        "names": record.get("names"),
        "location": record.get("location"),
        "rankings": record.get("rankings"),
        "admissions": record.get("admissions"),
        "fees": record.get("fees"),
        "placements": record.get("placements"),
        "courses": record.get("courses"),
        "regulatory": record.get("regulatory"),
    }
    try:
        summaries = await summarize_sections(facts)
        record.setdefault("sections", {})
        record["sections"].update(summaries)  # overview, admissions, fees, placements, contact
    except Exception:
        # keep prior summaries if summarizer fails
        pass

    # 5) Save
    await upsert_college(slug, record)
