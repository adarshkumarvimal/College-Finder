"""summarizer.py"""
import json
from typing import Dict, Any
from openai import OpenAI
from app.config import OPENAI_API_KEY, OPENAI_MODEL, OPENAI_TIMEOUT

_client = OpenAI(api_key=OPENAI_API_KEY) if OPENAI_API_KEY else None

SUMMARY_TEMPLATE = """You are given structured, up-to-date fields about a college.
Write concise, factual paragraphs for website sections. DO NOT invent numbers or claims.
If a field is missing, omit it rather than guessing.

Return JSON with keys: overview, admissions, fees, placements, contact.
Use 3–6 sentences for overview, 2–4 for others.
If you cite facts, refer generically to 'official sources' or 'regulatory bodies' (the site will show exact source links).
"""

def _messages(facts: Dict[str, Any]):
    return [
        {"role": "system", "content": "Return JSON only. No markdown."},
        {"role": "user", "content": SUMMARY_TEMPLATE},
        {"role": "user", "content": "FACTS_JSON:\n" + json.dumps(facts)},
    ]

async def summarize_sections(facts: Dict[str, Any]) -> Dict[str, str]:
    """summarize_sections"""
    if _client is None:
        # Simple fallback
        return {
            "overview": "This institution is recognized in India. (mock)",
            "admissions": "Admissions are based on merit and entrance tests. (mock)",
            "fees": "Fees vary by program and category. (mock)",
            "placements": "Recent placement reports indicate solid outcomes. (mock)",
            "contact": "Refer to the official website for contact details. (mock)",
        }

    resp = _client.chat.completions.create(
        model=OPENAI_MODEL,
        messages=_messages(facts),
        temperature=0.2,
        timeout=OPENAI_TIMEOUT,
        response_format={"type": "json_object"},
        max_tokens=700,
    )
    out = resp.choices[0].message.content or "{}"
    return json.loads(out)
