import re
from pydantic import BaseModel, validator
from typing import List, Dict, Optional, Union

class Location(BaseModel):
    city: Optional[str]
    state: Optional[str]
    country: Optional[str]

class Branding(BaseModel):
    # Accept str or None; coerce "" -> None
    logo_url: Optional[str] = None
    photo_url: Optional[str] = None
    image_alts: Dict[str, str] = {}

    @validator("logo_url", "photo_url", pre=True)
    def empty_to_none(cls, v):
        if v is None:
            return None
        if isinstance(v, str) and v.strip() == "":
            return None
        return v

class Sections(BaseModel):
    # keep strings; allow empty
    overview: str = ""
    courses: Union[List[str], str] = []
    fees: str = ""
    admissions: str = ""
    placements: str = ""
    contact: str = ""

    @validator("courses", pre=True)
    def courses_to_list(cls, v):
        if v is None:
            return []
        if isinstance(v, list):
            # normalize and strip empties
            return [str(x).strip() for x in v if str(x).strip()]
        if isinstance(v, str):
            # split on commas / newlines for lenient inputs
            parts = [p.strip("•- \t\r\n") for p in re.split(r"[,\n]+", v) if p.strip()]
            return parts
        # fallback
        return [str(v).strip()] if str(v).strip() else []

class Review(BaseModel):
    source: str
    snippet: str
    url: Optional[str] = None  # accept plain string or None

class DisambigOption(BaseModel):
    name: str
    city: Optional[str] = None
    state: Optional[str] = None
    country: Optional[str] = None
    slug: str

class CollegeData(BaseModel):
    query: str
    normalized_name: Optional[str] = None
    location: Optional[Location] = None
    branding: Optional[Branding] = None
    sections: Optional[Sections] = None
    reviews: List[Review] = []
    disclaimers: List[str] = []
    last_updated_iso: Optional[str] = None

    confidence: Optional[float] = None  # 0..1
    disambiguation: List[DisambigOption] = []

    @validator("confidence")
    def clamp_conf(cls, v):
        if v is None:
            return v
        return max(0.0, min(1.0, float(v)))