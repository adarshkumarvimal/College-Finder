"""db_schema.py"""
from typing import List, Optional, Dict, Any
from datetime import datetime
from pydantic import BaseModel, Field

class SourceStamp(BaseModel):
    """SourceStamp"""
    url: str
    fetched_at: datetime

class Regulatory(BaseModel):
    """Regulatory"""
    ugc: Optional[Dict[str, Any]] = None
    aicte: Optional[Dict[str, Any]] = None
    naac: Optional[Dict[str, Any]] = None

class Rankings(BaseModel):
    """Rankings"""
    nirf: Optional[Dict[str, Any]] = None

class CollegeRecord(BaseModel):
    """CollegeRecord"""
    slug: str
    # { official, aliases:[] }
    names: Dict[str, Any] = Field(default_factory=dict)
    # { city, state, country }
    location: Dict[str, Any] = Field(default_factory=dict)

    regulatory: Regulatory = Regulatory()
    rankings: Rankings = Rankings()

    # { exams:[], deadlines:[], source_url, last_seen }
    admissions: Dict[str, Any] = Field(default_factory=dict)
    # { ug_range, pg_range, source_url, last_seen }
    fees: Dict[str, Any] = Field(default_factory=dict)
    # { median_ctc, year, report_url, last_seen }
    placements: Dict[str, Any] = Field(default_factory=dict)
    # [{ name, level?, duration? }]
    courses: List[Dict[str, Any]] = Field(default_factory=list)

    last_full_refresh: Optional[datetime] = None
    next_due_refresh: Optional[datetime] = None

    # { created_at, updated_at, sources:[{field,url,fetched_at}] }
    audit: Dict[str, Any] = Field(default_factory=dict)
