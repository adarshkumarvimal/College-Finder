"""openai_client"""
import json
import re
from datetime import datetime
from typing import Any, Dict

from openai import OpenAI, APIConnectionError, RateLimitError, BadRequestError
from app.config import OPENAI_API_KEY, OPENAI_MODEL, OPENAI_TIMEOUT

client = OpenAI(api_key=OPENAI_API_KEY) if OPENAI_API_KEY else None

JSON_INSTRUCTIONS = """
Return ONLY valid, compact JSON (no markdown, no code fences).
Be concise; avoid filler text. If unknown, leave empty strings.
"""

SCHEMA = {
    "type": "object",
    "properties": {
        "query": {"type": "string"},
        "normalized_name": {"type": ["string", "null"]},
        "location": {
            "type": ["object", "null"],
            "properties": {
                "city": {"type": ["string", "null"]},
                "state": {"type": ["string", "null"]},
                "country": {"type": ["string", "null"]},
            },
            "required": ["city", "state", "country"],
            "additionalProperties": False,
        },
        "branding": {
            "type": ["object", "null"],
            "properties": {
                "logo_url": {"type": ["string", "null"]},
                "photo_url": {"type": ["string", "null"]},
                "image_alts": {
                    "type": "object",
                    "additionalProperties": {"type": "string"}
                },
            },
            "required": ["logo_url", "photo_url", "image_alts"],
            "additionalProperties": False,
        },
        "sections": {
            "type": ["object", "null"],
            "properties": {
                "overview": {"type": "string"},
                "courses": {                              # ⬅️ updated
                    "oneOf": [
                        {"type": "array", "items": {"type": "string"}},
                        {"type": "string"}
                    ]
                },
                "fees": {"type": "string"},
                "admissions": {"type": "string"},
                "placements": {"type": "string"},
                "contact": {"type": "string"},
            },
            "required": ["overview", "fees", "admissions", "placements", "contact"],
            "additionalProperties": False,
        },
        "reviews": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "source": {"type": "string"},
                    "snippet": {"type": "string"},
                    "url": {"type": ["string", "null"]},
                },
                "required": ["source", "snippet", "url"],
                "additionalProperties": False,
            },
        },
        "disclaimers": {"type": "array", "items": {"type": "string"}},
        "last_updated_iso": {"type": ["string", "null"]},
        "confidence": {"type": ["number", "null"]},
        "disambiguation": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "name": {"type": "string"},
                    "city": {"type": ["string", "null"]},
                    "state": {"type": ["string", "null"]},
                    "country": {"type": ["string", "null"]},
                    "slug": {"type": "string"}
                },
                "required": ["name", "slug"],
                "additionalProperties": False,
            }
        }
    },
    "required": ["query", "reviews", "disclaimers", "disambiguation"],
    "additionalProperties": False,
}

def _slugify(text: str) -> str:
    t = re.sub(r"[^a-zA-Z0-9\s-]", "", text.strip().lower())
    t = re.sub(r"[ \t\n\r-]+", "-", t).strip("-")
    return t or "college"

def _mock(query: str) -> Dict[str, Any]:
    # Fallback if no API key or repeated failures
    name = query.title()
    return {
        "query": query,
        "normalized_name": name,
        "location": {"city": "Sample City", "state": "Sample State", "country": "India"},
        "branding": {
            "logo_url": "https://upload.wikimedia.org/wikipedia/commons/a/ac/No_image_available.svg",
            "photo_url": "https://upload.wikimedia.org/wikipedia/commons/3/3f/Placeholder_view_vector.svg",
            "image_alts": {"logo": f"{name} logo", "photo": f"Campus photo of {name}"},
        },
        "sections": {
            "overview": f"{name} is a reputed institution. (mock)",
            "courses": [
                "B.A. LL.B. (Hons.)",
                "LL.B.",
                "LL.M.",
                "Diploma in Corporate Law"
            ],
            "fees": "Varies by program. (mock)",
            "admissions": "Entrance-based. (mock)",
            "placements": "Strong alumni network. (mock)",
            "contact": "Official website goes here. (mock)",
        },
        "reviews": [
            {"source": "Shiksha", "snippet": "Positive campus life (paraphrased).", "url": "https://www.shiksha.com/"},
            {"source": "Collegedunia", "snippet": "Good infrastructure (paraphrased).", "url": "https://collegedunia.com/"},
            {"source": "Quora", "snippet": "Strong peer culture (paraphrased).", "url": "https://www.quora.com/"},
        ],
        "disclaimers": [
            "AI-generated; verify with official sources.",
            "Paraphrased review summaries.",
        ],
        "last_updated_iso": datetime.utcnow().isoformat() + "Z",
        "confidence": 0.5,
        "disambiguation": [],
    }

PROMPT_TEMPLATE = """You are an assistant that returns STRICT JSON for college information.

Target college query: "{query}"

{json_instructions}

JSON schema:
{schema}

Content rules:
- Be concise.
- sections.courses: prefer an ARRAY of 6–12 representative programs; if unsure, a shorter list is okay.
- Reviews: 3 very short paraphrases with plausible site URLs.
- If multiple colleges fit, fill `disambiguation` with 2–6 options (include a `slug` for `/college/{{slug}}`).
Return only JSON.
"""

def _extract_json(text: str) -> Dict[str, Any]:
    # If the model ever wraps in fences, strip them:
    text = text.strip()
    if text.startswith("```"):
        text = text.strip("`")
        if text.startswith("json"):
            text = text[4:].strip()
    return json.loads(text)

async def generate_college_json(query: str) -> Dict[str, Any]:
    """generate college json"""
    if client is None:
        return _mock(query)

    messages = [
        {"role": "system", "content": "You return valid JSON only. No markdown."},
        {
            "role": "user",
            "content": PROMPT_TEMPLATE.format(
                query=query, json_instructions=JSON_INSTRUCTIONS.strip(), schema=json.dumps(SCHEMA, indent=0)
            ),
        },
    ]

    last_err = None
    for attempt in range(2):  # ↓ fewer retries
        try:
            resp = client.chat.completions.create(
                model=OPENAI_MODEL,
                messages=messages,
                temperature=0.1,
                timeout=OPENAI_TIMEOUT,
                max_tokens=900,  # enough for our compact JSON
                response_format={"type": "json_object"},  # helps speed & correctness
            )
            raw = resp.choices[0].message.content or "{}"
            payload = _extract_json(raw)
            # ... keep your disambiguation slugification + defaults ...
            # (unchanged)
            return payload
        except Exception as e:
            last_err = e
            messages.append({"role": "system", "content": "Respond with VALID JSON only."})
            continue

    return _mock(query)
