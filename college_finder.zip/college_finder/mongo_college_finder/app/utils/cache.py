"""app/utils/cache.py"""
import json
from typing import Optional, Any

try:
    from redis.asyncio import Redis
except Exception:  # redis not installed -> Optional
    Redis = None  # type: ignore

class RedisSWRCache:
    """
    Redis cache with Stale-While-Revalidate.
    We keep two keys per item:
      - fresh key (short TTL) -> instant serve when present
      - stale key (long TTL)  -> fallback if fresh expired, while we refresh in background
    """

    def __init__(self, redis: "Redis", prefix: str = "college"):
        self.r = redis
        self.prefix = prefix

    def _k_fresh(self, key: str) -> str:
        return f"{self.prefix}:{key}:fresh"

    def _k_stale(self, key: str) -> str:
        return f"{self.prefix}:{key}:stale"

    async def get_fresh(self, key: str) -> Optional[Any]:
        raw = await self.r.get(self._k_fresh(key))
        return json.loads(raw) if raw else None

    async def get_stale(self, key: str) -> Optional[Any]:
        raw = await self.r.get(self._k_stale(key))
        return json.loads(raw) if raw else None

    async def set_both(self, key: str, value: Any, fresh_ttl: int, stale_ttl: int) -> None:
        j = json.dumps(value)
        await self.r.set(self._k_fresh(key), j, ex=fresh_ttl)
        await self.r.set(self._k_stale(key), j, ex=stale_ttl)
