"""main.py"""
import re
from datetime import datetime
from fastapi import FastAPI, Request, Form, BackgroundTasks
from fastapi.responses import RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.middleware.cors import CORSMiddleware
from starlette.status import HTTP_302_FOUND
from config import USE_REDIS, REDIS_URL, CACHE_TTL, STALE_TTL
from scheduler import init_scheduler
from .utils.cache import RedisSWRCache, Redis  # your earlier SWR cache
from .utils.openai_client import generate_college_json  # still used for fallbacks if not in DB yet
from .db.mongo import find_college, upsert_college
from .services.refresher import refresh_college


app = FastAPI(title="College Finder")
app.mount("/static", StaticFiles(directory="app/static"), name="static")
templates = Jinja2Templates(directory="app/templates")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"],
)

def slugify(text: str) -> str:
    """slugify"""
    text = text.lower().strip()
    text = re.sub(r"[^a-z0-9\s-]", "", text)
    text = re.sub(r"[\s-]+", "-", text)
    return text.strip("-")

@app.on_event("startup")
async def _startup():
    # Redis cache
    app.state.cache = None
    if USE_REDIS and Redis is not None:
        app.state.redis = Redis.from_url(REDIS_URL, decode_responses=True)
        app.state.cache = RedisSWRCache(app.state.redis, prefix="college")
    # APScheduler
    init_scheduler()

@app.get("/")
async def home(request: Request):
    """home"""
    return templates.TemplateResponse("index.html", {"request": request})

@app.post("/search")
async def search(q: str = Form(...)):
    """search"""
    s = slugify(q)
    return RedirectResponse(url=f"/college/{s}", status_code=HTTP_302_FOUND)

def _view_model_from_db(doc: dict) -> dict:
    """
    Map DB record -> the structure your Jinja template expects (`data`).
    """
    names = doc.get("names") or {}
    loc = doc.get("location") or {}
    branding = doc.get("branding") or {}
    sections = (doc.get("sections") or {}) | {
        # keep defaults so template never breaks
        "overview": (doc.get("sections") or {}).get("overview", ""),
        "admissions": (doc.get("sections") or {}).get("admissions", ""),
        "fees": (doc.get("sections") or {}).get("fees", ""),
        "placements": (doc.get("sections") or {}).get("placements", ""),
        "contact": (doc.get("sections") or {}).get("contact", ""),
        "courses": (doc.get("courses") or []),  # courses kept as list for your new tab
    }
    reviews = doc.get("reviews") or []  # optional
    return {
        "query": names.get("official", ""),
        "normalized_name": names.get("official", ""),
        "location": {"city": loc.get("city"), "state": loc.get("state"),
                     "country": loc.get("country", "India")},
        "branding": {
            "logo_url": branding.get("logo_url", ""),
            "photo_url": branding.get("photo_url", ""),
            "image_alts": branding.get("image_alts", {}),
        },
        "sections": sections,
        "reviews": reviews,
        "disclaimers": ["Data aggregated from official/regulatory sources."],
        "last_updated_iso": (doc.get("audit") or {}).get("updated_at", ""),
    }

async def _serve_from_db_or_background(slug: str, background_tasks: BackgroundTasks | None, request: Request):
    """db_or_background"""
    query = slug.replace("-", " ")
    cache: RedisSWRCache = getattr(app.state, "cache", None)

    # 1) Redis fresh
    if cache:
        cached = await cache.get_fresh(slug)
        if cached:
            return templates.TemplateResponse("college.html",
                                              {"request": request,"data": cached,
                                               "now": datetime.now().isoformat()+"Z"})

    # 2) Mongo read (fast)
    doc = await find_college(slug)
    if doc:
        vm = _view_model_from_db(doc)
        # serve and refresh in background if due
        if cache:
            await cache.set_both(slug, vm, fresh_ttl=CACHE_TTL, stale_ttl=STALE_TTL)
        if background_tasks:
            background_tasks.add_task(refresh_college, slug)
        return templates.TemplateResponse("college.html",
                                          {"request": request, "data": vm,
                                           "now": datetime.now().isoformat()+"Z"})

    # 3) Fallback: if not in DB at all,
    # generate a minimal seed using your old generator (1st visit only)
    seed = await generate_college_json(query)
    names = {"official": seed.get("normalized_name") or query, "aliases": [query]}
    # Initialize minimal doc, then kick refresh pipeline
    await upsert_college(slug, {"_id": slug, "names": names,
                                "audit": {"created_at": datetime.now().isoformat()+"Z"}})
    if background_tasks:
        background_tasks.add_task(refresh_college, slug)

    # show a lightweight placeholder until refresh completes
    vm = {
        "query": names["official"],
        "normalized_name": names["official"],
        "location": {"city": "", "state": "", "country": "India"},
        "branding": {"logo_url": "", "photo_url": "", "image_alts": {}},
        "sections": {"overview": "Fetching fresh data…",
                     "admissions": "",
                     "fees": "",
                     "placements": "",
                     "contact": "",
                     "courses": []},
        "reviews": [],
        "disclaimers": ["Live data is being fetched from official sources."],
        "last_updated_iso": "",
    }
    if cache:
        await cache.set_both(slug, vm, fresh_ttl=60, stale_ttl=300)
    return templates.TemplateResponse("college.html",
                                      {"request": request,
                                       "data": vm, "now": datetime.now().isoformat()+"Z"})

@app.get("/college/{slug}")
async def college_detail(
    request: Request,
    slug: str, refresh: int = 0,
    background_tasks: BackgroundTasks = None
):
    """college_detail"""
    if refresh == 1:
        # force background refresh + serve DB (or placeholder)
        if background_tasks:
            background_tasks.add_task(refresh_college, slug)
    return await _serve_from_db_or_background(slug, background_tasks, request)
