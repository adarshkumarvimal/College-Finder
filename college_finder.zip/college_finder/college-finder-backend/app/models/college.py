from sqlmodel import SQLModel, Field, Column
from typing import Optional
from sqlalchemy import JSON
from datetime import datetime

class College(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    name: str = Field(index=True)
    normalized_name: str = Field(index=True)
    overview: Optional[str] = None
    courses: Optional[str] = None
    admission: Optional[str] = None
    fees: Optional[str] = None
    placements: Optional[str] = None
    contact: Optional[str] = None
    resources: Optional[dict] = Field(sa_column=Column(JSON), default=None)
    source_metadata: Optional[dict] = Field(sa_column=Column(JSON), default=None)
    fetched_at: datetime = Field(default_factory=datetime.utcnow)
