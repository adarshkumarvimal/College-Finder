from pydantic_settings import BaseSettings
import os

class Settings(BaseSettings):
    DATABASE_URL: str = "mysql+aiomysql://user:password@localhost:3306/college_db"
    OPENAI_API_KEY: str
    OPENAI_MODEL: str = "gpt-4o-mini"
    CACHE_TTL_SECONDS: int = 60 * 60 * 24 * 7  # 7 days

    class Config:
        env_file = ".env"

settings = Settings()
