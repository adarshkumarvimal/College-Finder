from pydantic import BaseModel
from typing import Optional, Dict, Any
from datetime import datetime

class CollegeCreate(BaseModel):
    name: str
    normalized_name: Optional[str]

class CollegeResponse(BaseModel):
    id: int
    name: str
    normalized_name: str
    overview: Optional[str]
    courses: Optional[str]
    admission: Optional[str]
    fees: Optional[str]
    placements: Optional[str]
    contact: Optional[str]
    resources: Optional[Dict[str, Any]]
    source_metadata: Optional[Dict[str, Any]]
    fetched_at: datetime

    class Config:
        orm_mode = True
