from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from app.db.session import get_session
from sqlmodel.ext.asyncio.session import AsyncSession
from app.services.college_service import get_or_create_college
from app.schemas.college import CollegeResponse

router = APIRouter()

class SearchRequest(BaseModel):
    query: str

@router.post("/search", response_model=CollegeResponse)
async def search_college(req: SearchRequest, db: AsyncSession = Depends(get_session)):
    q = (req.query or "").strip()
    if not q:
        raise HTTPException(status_code=400, detail="query is required")
    college, created = await get_or_create_college(db, q)
    return college
