from fastapi import FastAPI
from app.api import search
from app.db.session import init_db
from app.core.config import settings

app = FastAPI(title="College Finder API (local)")

app.include_router(search.router, prefix="/api")

@app.on_event("startup")
async def on_startup():
    await init_db()

@app.get("/health")
async def health():
    return {"status": "ok"}

# from fastapi import FastAPI
# from fastapi.staticfiles import StaticFiles
# from fastapi.responses import FileResponse
# from app.api import search
# from app.db.session import init_db

# app = FastAPI(title="College Finder API (local)")

# # Serve static folder
# app.mount("/static", StaticFiles(directory="static"), name="static")

# # Default routes for frontend
# @app.get("/")
# async def serve_search_page():
#     return FileResponse("static/search.html")

# @app.get("/result")
# async def serve_result_page():
#     return FileResponse("static/result.html")

# @app.get("/error")
# async def serve_error_page():
#     return FileResponse("static/error.html")


# # API Routes
# app.include_router(search.router, prefix="/api")


# @app.on_event("startup")
# async def on_startup():
#     await init_db()

# @app.get("/health")
# async def health():
#     return {"status": "ok"}

