# import json
# import openai
# from app.core.config import settings

# openai.api_key = settings.OPENAI_API_KEY

# SYSTEM_PROMPT = (
#     "You are a structured-data extractor for colleges. "
#     "Given a college name, return a JSON object EXACTLY with keys: "
#     "overview (string), courses (string), admission (string), fees (string), "
#     "placements (string), contact (string), resources (object with keys: logo (array), photos (array), website (string)), "
#     "source_suggestions (array of urls). Use empty string or empty array if unknown. "
#     "Return only the JSON object, nothing else."
# )

# async def fetch_college_from_openai(college_name: str) -> dict:
#     prompt = (
#         f"Extract detailed info for this college and return JSON ONLY.\n\nCollege name: {college_name}\n\n"
#         "Fields: overview, courses, admission, fees, placements, contact, resources (logo[], photos[], website), source_suggestions[]."
#     )

#     # Using synchronous method via openai library because the official python lib may not provide an async helper.
#     # This call is blocking but okay for a starter. If you prefer non-blocking, run it in a thread pool.
#     resp = openai.ChatCompletion.create(
#         model=settings.OPENAI_MODEL,
#         messages=[
#             {"role": "system", "content": SYSTEM_PROMPT},
#             {"role": "user", "content": prompt},
#         ],
#         temperature=0.0,
#         max_tokens=1200,
#     )

#     content = resp.choices[0].message.content
#     try:
#         data = json.loads(content)
#         return data
#     except Exception:
#         # try to extract JSON substring
#         import re
#         m = re.search(r"\{.*\}", content, flags=re.S)
#         if m:
#             try:
#                 return json.loads(m.group(0))
#             except Exception:
#                 pass
#     # fallback empty structure
#     return {
#         "overview": "",
#         "courses": "",
#         "admission": "",
#         "fees": "",
#         "placements": "",
#         "contact": "",
#         "resources": {"logo": [], "photos": [], "website": ""},
#         "source_suggestions": [],
#     }





import json
import asyncio
from openai import OpenAI
from app.core.config import settings

# Initialize the new client
client = OpenAI(api_key=settings.OPENAI_API_KEY)

SYSTEM_PROMPT = (
    "You are a structured-data extractor for colleges. "
    "Given a college name, return a JSON object EXACTLY with keys: "
    "overview (string), courses (string), admission (string), fees (string), "
    "placements (string), contact (string), resources (object with keys: logo (array), photos (array), website (string)), "
    "source_suggestions (array of urls). Use empty string or empty array if unknown. "
    "Return only the JSON object, nothing else."
)


async def fetch_college_from_openai(college_name: str) -> dict:
    prompt = (
        f"Extract detailed info for this college and return JSON ONLY.\n\n"
        f"College name: {college_name}\n\n"
        "Fields: overview, courses, admission, fees, placements, contact, "
        "resources (logo[], photos[], website), source_suggestions[]."
    )

    # The new OpenAI client is synchronous; run it in a thread so it doesn't block the event loop
    response = await asyncio.to_thread(
        client.chat.completions.create,
        model=settings.OPENAI_MODEL,
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": prompt},
        ],
        temperature=0.0,
        max_tokens=1200,
    )

    content = response.choices[0].message.content

    # Try to parse JSON from the model output
    try:
        data = json.loads(content)
        return data
    except Exception:
        # Try to extract a JSON object substring if the model added extra text
        import re

        match = re.search(r"\{.*\}", content, flags=re.S)
        if match:
            try:
                return json.loads(match.group(0))
            except Exception:
                pass

    # Fallback empty structure
    return {
        "overview": "",
        "courses": "",
        "admission": "",
        "fees": "",
        "placements": "",
        "contact": "",
        "resources": {"logo": [], "photos": [], "website": ""},
        "source_suggestions": [],
    }
