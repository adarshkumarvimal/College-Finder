from app.models.college import College
from app.utils.normalize import normalize_college_name
from app.services.openai_client import fetch_college_from_openai
from datetime import datetime
from app.core.config import settings
from sqlmodel import select
from sqlmodel.ext.asyncio.session import AsyncSession
from typing import Tuple, Optional

CACHE_TTL = int(settings.CACHE_TTL_SECONDS)

async def get_college_by_query(db: AsyncSession, query: str) -> Optional[College]:
    norm = normalize_college_name(query)
    statement = select(College).where(College.normalized_name == norm)
    res = await db.execute(statement)
    return res.scalars().first()

async def upsert_college_from_openai(db: AsyncSession, name: str) -> College:
    norm = normalize_college_name(name)
    payload = await fetch_college_from_openai(name)

    resources = payload.get("resources", {})
    college = College(
        name=name,
        normalized_name=norm,
        overview=payload.get("overview", ""),
        courses=payload.get("courses", ""),
        admission=payload.get("admission", ""),
        fees=payload.get("fees", ""),
        placements=payload.get("placements", ""),
        contact=payload.get("contact", ""),
        resources=resources,
        source_metadata={"suggested_sources": payload.get("source_suggestions", [])},
        fetched_at=datetime.utcnow(),
    )
    db.add(college)
    await db.commit()
    await db.refresh(college)
    return college

async def get_or_create_college(db: AsyncSession, name: str) -> Tuple[College, bool]:
    existing = await get_college_by_query(db, name)
    if existing:
        age = datetime.utcnow() - existing.fetched_at
        if age.total_seconds() < CACHE_TTL:
            return existing, False
    college = await upsert_college_from_openai(db, name)
    return college, True
